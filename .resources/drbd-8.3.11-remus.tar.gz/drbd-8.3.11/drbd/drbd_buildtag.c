/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 0de839cee13a4160eed6037c4bddd066645e23c5"
		" build by phil@fat-tyre, 2011-06-29 11:37:11";
}
